import numpy as np

def precision_weighted_fusion(means, covariances):
    """Equation (2): Gaussian precision-weighted fusion."""
    means = [np.asarray(m, dtype=float) for m in means]
    covariances = [np.asarray(c, dtype=float) for c in covariances]
    precisions = [np.linalg.inv(c) for c in covariances]
    precision_sum = np.sum(precisions, axis=0)
    sigma_f = np.linalg.inv(precision_sum)
    weighted = np.sum([P @ m for P, m in zip(precisions, means)], axis=0)
    mu_f = sigma_f @ weighted
    return mu_f, sigma_f

def temperature_dependent_parameters(Tw, Tm, Rs0, lambda_pm0,
                                     alpha_cu, alpha_pm, T_ref):
    """Equation (7)."""
    Rs = Rs0 * (1.0 + alpha_cu * (Tw - T_ref))
    lambda_pm = lambda_pm0 * (1.0 + alpha_pm * (Tm - T_ref))
    return Rs, lambda_pm

def saturation_inductances(i_d, i_q, Ld0, Lq0,
                           a_d=0.0, b_d=0.0, c_d=0.0,
                           a_q=0.0, b_q=0.0, c_q=0.0):
    """Equation (8). Currents should be normalized by rated current."""
    Ld = Ld0 * (1 + a_d*i_d**2 + b_d*i_q**2 + c_d*i_d*i_q)
    Lq = Lq0 * (1 + a_q*i_d**2 + b_q*i_q**2 + c_q*i_d*i_q)
    return Ld, Lq

def dq_voltages(i_d, i_q, di_d_dt, di_q_dt, omega_e,
                Rs, Ld, Lq, lambda_pm):
    """Equations (5)-(6)."""
    vq = Rs*i_q + Lq*di_q_dt + omega_e*Ld*i_d + omega_e*lambda_pm
    vd = Rs*i_d + Ld*di_d_dt - omega_e*Lq*i_q
    return vd, vq

def electromagnetic_torque(pole_pairs, i_d, i_q, Ld, Lq, lambda_pm):
    """Equation (9)."""
    return 1.5 * pole_pairs * i_q * (lambda_pm + (Ld - Lq)*i_d)

def losses(I_rms, Rs, f, Bm, kh, kc, ke=0.0):
    """Equation (10)."""
    Pcu = 3.0 * I_rms**2 * Rs
    Pfe = kh*f*Bm**2 + kc*(f**2)*Bm**2 + ke*(f**1.5)*(Bm**1.5)
    return Pcu, Pfe

def thermal_step(Tw, Tm, Ta, Pcu, Pfe, dt,
                 Cw, Cm, gamma_fe, gamma_m, h_wa, h_wm, h_ma):
    """Forward-Euler form of Equations (3)-(4)."""
    dTw = (Pcu + gamma_fe*Pfe - h_wa*(Tw-Ta) - h_wm*(Tw-Tm)) / Cw
    dTm = (gamma_m*Pfe + h_wm*(Tw-Tm) - h_ma*(Tm-Ta)) / Cm
    return Tw + dt*dTw, Tm + dt*dTm

def cycle_efficiency(Pshaft, Pin, t):
    """Equation (11): energy-based drive-cycle efficiency."""
    Pshaft = np.asarray(Pshaft, dtype=float)
    Pin = np.asarray(Pin, dtype=float)
    t = np.asarray(t, dtype=float)
    return np.trapz(Pshaft, t) / np.trapz(Pin, t)

def credible_interval(samples, level=0.95):
    samples = np.asarray(samples, dtype=float)
    alpha = (1-level)/2
    return (np.quantile(samples, alpha),
            np.quantile(samples, 0.5),
            np.quantile(samples, 1-alpha))
