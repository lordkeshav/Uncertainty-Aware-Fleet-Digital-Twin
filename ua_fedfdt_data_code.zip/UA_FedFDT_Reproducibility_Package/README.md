# UA-FedFDT Reproducibility Package

Paper: **Privacy-Preserving Uncertainty-Aware Fleet Digital Twin for
Predicting PMSM Efficiency Under Unseen Electric-Vehicle Load Profiles**

This package was prepared from the supplied `Access_keshVSIR.docx`.

## Exact data included

The following CSVs are direct transcriptions of numerical data printed in the
paper:

- `machine_parameters_table_I.csv`
- `model_update_strategies_table_II.csv`
- `fleet_posterior_estimates_table_III.csv`
- `validation_results_table_IV.csv`
- `wltp_ablation_results.csv`
- `benchmark_protocol.csv`
- `performance_metrics.csv`

The main WLTP values reproduced exactly are:

- Datasheet efficiency error: 4.42 percentage points
- Centralized FDT efficiency error: 1.28 percentage points
- Deterministic FedFDT efficiency error: 1.17 percentage points
- Proposed UA-FedFDT efficiency error: 0.53 percentage points
- Predictive interval coverage: 94.6%
- Trust: 91.4%

## Important provenance limitation

The paper explicitly states that raw fleet data are not publicly available and
that the study uses a simulation benchmark. The DOCX does not contain the
original per-sample simulation arrays, random seed, all thermal coefficients,
all saturation coefficients, local prior covariances, measurement-noise
parameters, exact drive-cycle generator, or the explicit trust-score formula.

Therefore this package does **not** invent those missing values and label them
as the original dataset.

Instead:

- Tables I-IV and the ablation values are exact.
- Figure 4 drive-cycle profiles are **digitized from the embedded raster image**
  and exported at 10 s spacing.
- Figure 7 scatter points are **digitized from the embedded raster image**.
- Figures 3 and 6 are preserved under `source_figures/`, because their original
  overlapping rasterized traces cannot be separated into exact source arrays
  without making unsupported assumptions.
- `FIGURE_DATA_STATUS.csv` documents this distinction.

## Working Python code

`ua_fedfdt_core.py` implements the mathematical equations stated in the paper:
precision-weighted posterior fusion, thermal observer, dq-axis model,
temperature dependence, saturation model, torque, losses, and cycle
efficiency.

`ua_fedfdt_reproduce.py` regenerates the exact Figure-5 bar chart from Table IV,
plots the digitized Figure-4 and Figure-7 data, and validates the key WLTP
numbers.

Run:

```bash
pip install numpy matplotlib
python ua_fedfdt_reproduce.py
```

No network access is required.

## Scientific use

The exact table CSVs can be used as supplemental numerical result tables. The
digitized files are suitable for plot reproduction and sensitivity checking,
but they should not be described as the unavailable original raw experimental
or simulation logs.
