#!/usr/bin/env python3
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "generated_figures"
OUT.mkdir(exist_ok=True)

def read(name):
    with open(DATA/name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

# Figure 5 — exact from Table IV
rows = read("validation_results_table_IV.csv")
cycles = [r["cycle"] for r in rows]
series = [
    ("Datasheet", "datasheet_error_pp"),
    ("Centralized FDT", "centralized_FDT_error_pp"),
    ("FedFDT", "FedFDT_error_pp"),
    ("Proposed UA-FedFDT", "UA_FedFDT_error_pp"),
]
x = np.arange(len(cycles))
w = 0.18
for i, (label, col) in enumerate(series):
    plt.bar(x + (i-1.5)*w, [float(r[col]) for r in rows], width=w, label=label)
plt.xticks(x, cycles)
plt.ylabel("Absolute efficiency error (percentage points)")
plt.legend()
plt.tight_layout()
plt.savefig(OUT/"figure5_efficiency_error.png", dpi=220)
plt.close()

# Figure 4 — digitized from embedded raster
rows = read("fig04_drive_cycles_digitized.csv")
t = np.array([float(r["time_s"]) for r in rows])
for col, label in [
    ("Staircase_training","Staircase training"),
    ("NEDC_training","NEDC training"),
    ("WLTP_unseen","WLTP unseen"),
    ("US06_unseen","US06 unseen"),
]:
    plt.plot(t, [float(r[col]) for r in rows], label=label)
plt.xlabel("Time (s)")
plt.ylabel("Electrical speed (rad/s)")
plt.legend()
plt.tight_layout()
plt.savefig(OUT/"figure4_drive_cycles_digitized.png", dpi=220)
plt.close()

# Figure 7 — digitized scatter
rows = read("fig07_trust_vs_ood_digitized.csv")
ood = np.array([float(r["normalized_out_of_domain_index"]) for r in rows])
trust = np.array([float(r["trust_pct"]) for r in rows])
plt.scatter(ood, trust, s=12)
plt.axhline(90, linestyle="--", label="recommended acceptance threshold")
plt.xlabel("Normalized out-of-domain index")
plt.ylabel("Trust level (%)")
plt.ylim(65,100)
plt.xlim(0,1)
plt.legend()
plt.tight_layout()
plt.savefig(OUT/"figure7_trust_vs_ood_digitized.png", dpi=220)
plt.close()

# Posterior comparison
rows = read("fleet_posterior_estimates_table_III.csv")
names = [r["parameter"] for r in rows]
true = np.array([float(r["true_fleet_mean"]) for r in rows])
post = np.array([float(r["posterior_mean"]) for r in rows])
std = np.array([float(r["posterior_std"]) for r in rows])
xx = np.arange(len(names))
plt.errorbar(xx, post, yerr=std, fmt="o", capsize=4, label="Posterior mean ± std")
plt.scatter(xx, true, marker="x", label="True fleet mean")
plt.xticks(xx, names)
plt.ylabel("Parameter value (mixed units; see CSV)")
plt.legend()
plt.tight_layout()
plt.savefig(OUT/"posterior_estimates.png", dpi=220)
plt.close()

# Numerical validation
wltp = next(r for r in rows if False) if False else None
v = {r["cycle"]: r for r in read("validation_results_table_IV.csv")}
assert abs(float(v["WLTP"]["datasheet_error_pp"]) - 4.42) < 1e-12
assert abs(float(v["WLTP"]["centralized_FDT_error_pp"]) - 1.28) < 1e-12
assert abs(float(v["WLTP"]["UA_FedFDT_error_pp"]) - 0.53) < 1e-12
assert abs(float(v["WLTP"]["predictive_interval_coverage_pct"]) - 94.6) < 1e-12
assert abs(float(v["WLTP"]["trust_pct"]) - 91.4) < 1e-12

print("Validation passed.")
print("WLTP: datasheet 4.42 pp, centralized FDT 1.28 pp, UA-FedFDT 0.53 pp.")
print("WLTP predictive interval coverage: 94.6%; trust: 91.4%.")
print("Generated plots:", OUT)
